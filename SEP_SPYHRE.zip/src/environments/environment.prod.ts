export const environment = {
  production: true,
  apiUrl: 'https://sepapi.azaz.com/api/'
};
