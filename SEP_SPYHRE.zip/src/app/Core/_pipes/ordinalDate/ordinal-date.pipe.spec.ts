import { OrdinalDatePipe } from './ordinal-date.pipe';

describe('OrdinalDatePipe', () => {
  it('create an instance', () => {
    const pipe = new OrdinalDatePipe();
    expect(pipe).toBeTruthy();
  });
});
