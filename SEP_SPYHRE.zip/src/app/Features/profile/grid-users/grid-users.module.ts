import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GridUsersRoutingModule } from './grid-users-routing.module';
import { GridUsersComponent } from './grid-users.component';
import { ReactiveFormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http'
import { FeaturesModule } from '../../Features.module';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
  declarations: [GridUsersComponent],
  imports: [
    CommonModule,
    GridUsersRoutingModule, NgxSpinnerModule,
    ReactiveFormsModule, HttpClientModule, FeaturesModule
  ]
})
export class GridUsersModule { }
