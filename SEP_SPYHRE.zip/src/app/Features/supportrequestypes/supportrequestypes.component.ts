import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/Core/_providers/api-service/api.service';
import {

  trigger,

  state,

  style,

  animate,

  transition

} from '@angular/animations';
import { NgxSpinnerService } from 'ngx-spinner';
import * as alertify from 'alertifyjs'
@Component({
  selector: 'app-supportrequestypes',
  templateUrl: './supportrequestypes.component.html',
  styleUrls: ['./supportrequestypes.component.scss'],
  animations: [

    trigger('fadeInOut', [

      state('in', style({ opacity: 1, transform: 'translateY(0)' })),

      transition('void => *', [

        style({ opacity: 0, transform: 'translateY(100%)' }),

        animate(800)

      ]),

      transition('* => void', [

        animate(800, style({ opacity: 0, transform: 'translateY(100%)' }))

      ])

    ])

  ]
})
export class SupportrequestypesComponent implements OnInit {
  projectdata: any;
  showAddPanel: boolean = false;
  showGrid: boolean = true;
  save1: boolean = false;
  save2: boolean = false;
  gustform: FormGroup;
  submitted: boolean;
  projectinsert: any;
  RT_ID: any;
  SRT_SRT_ID: any;
  SRT_ID: any;
  display123: boolean = true;
  hideall: boolean;
  isactive: boolean;
  isinactive: boolean;
  isstatus: boolean;
  dummy: string;

  constructor(public srvc: ApiService, public fb: FormBuilder, public rtr: Router, private spinner: NgxSpinnerService) {
    this.gustform = this.fb.group({
      requestname: ['', Validators.required],
      type: ["", Validators.required],
      SRT_ACTIVE: [''],
    });
  }

  ngOnInit(): void {
    this.getdata()

  }
  getdata() {
    this.spinner.show();
    this.showGrid = false;
    let obj = {
      "Id": "",
      "Expression": ""
    }
    this.srvc.postmethod('supportrequesttype/get', obj).subscribe(res => {

      this.projectdata = res.response;
      this.spinner.hide();
      this.showGrid = true;

      console.log(this.projectdata);
    })
  }
  addinsert() {
    this.submitted = false;
    this.showAddPanel = true;
    this.showGrid = false;
    this.save1 = true;
    this.save2 = false;
    this.display123 = false;
    this.hideall = false;
    this.gustform.reset();
  }
  EditPanel(Id) {
    console.log(Id);
    this.gustform.controls["requestname"].setValue(Id.SRT_NAME);
    this.gustform.controls["type"].setValue(Id.SRT_SRT_ID);
    this.SRT_ID = Id.SRT_ID;
    this.showAddPanel = true;
    this.showGrid = false;
    this.save1 = false;
    this.display123 = false;
    this.save2 = true;
    this.hideall = true;
    this.isactive = Id.SRT_ACTIVE == "Y";
    this.isinactive = Id.SRT_ACTIVE == "D";
    if (Id.SRT_ACTIVE == "Y") {
      this.gustform.controls["SRT_ACTIVE"].setValue(Id.SRT_ACTIVE)

    }
    if (this.isactive == true) {
      this.dummy = 'Y'
    }
    if (this.isinactive == true) {
      this.dummy = 'D'
    }
  }
  insert() {
    this.submitted = true;
    if (this.gustform.invalid) {
      return false;
    }
    const obj = {
      "SRT_SRT_ID": this.gustform.value.type,
      "SRT_NAME": this.gustform.value.requestname,
      "SRT_GROUP_EMAIL": "test@gmail.com",
      "SRT_ACTIVE": "Y",
      "SRT_U_ID": 2,
    }
    this.srvc.postmethod('supportrequesttype', obj).subscribe(res => {
      console.log(res)
      this.projectinsert = res.response;
      console.log(this.projectinsert);
      alertify.success('Record inserted successfully')
      this.getdata();
    })
    this.showAddPanel = false;
    this.display123 = true;
    this.gustform.reset();
  }
  get f() { return this.gustform.controls; }
  saveedit() {
    this.submitted = true;
    if (this.gustform.invalid) {
      return false;
    }

    const obj = {

      "SRT_ID": this.SRT_ID,
      "SRT_SRT_ID": this.gustform.value.type,
      "SRT_NAME": this.gustform.value.requestname,
      "SRT_GROUP_EMAIL": "test@gmail.com",
      "SRT_ACTIVE": this.dummy,
      "SRT_U_ID": 2,
    }

    this.srvc.putmethod('supportrequesttype', obj).subscribe(data => {
      console.log(data);
      alertify.success('Record updated successfully')
      this.getdata();
    });
    this.showAddPanel = false;
    this.display123 = true;

  }
  delete(id: any) {
    if (window.confirm('are you sure to delete this record?')) {
      this.SRT_ID = id.SRT_ID;
      const obj = {
        "SRT_ID": this.SRT_ID,
      }
      this.srvc.deletemethod('supportrequesttype', obj).subscribe(res => {
        console.log(res)
        alertify.error('Record deleted successfully')
        this.getdata();
      })
    }

  }
  Cancel() {
    this.showAddPanel = false;
    this.showGrid = true;
    this.display123 = true;
    this.gustform.reset();
  }

  viewall() {
    this.showAddPanel = false;
    this.showGrid = true;
  }
  status(val) {

    if (val == true) {
      this.dummy = "Y";
      this.isactive = true;
      this.isinactive = false;
    }
    else {
      this.dummy = "D";
      this.isactive = false;
      this.isinactive = true;
    }

  }





}
